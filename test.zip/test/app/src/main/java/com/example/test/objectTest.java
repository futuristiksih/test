package com.example.test;

public class objectTest {
    private String test;
    objectTest(){}
    objectTest(String test){
        this.test=test;
    }
    public String getTest(){return test;}
}
